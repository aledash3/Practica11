#include "Headers/logic_cliente.h"
#include "Headers/clienteDAO.h"
#include "Headers/cliente.h" // Asegúrate de incluir el archivo de cabecera de Cliente
#include <sstream>

// Función split para dividir una cadena en un vector de cadenas según un delimitador
std::vector<std::string> split(std::string_view s, char delimiter) {
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream tokenStream(s.data());
    while (std::getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

bool Logic_Cliente::validarCliente(std::string cedula) {
    std::vector<std::string> clientes = cdao.loadClientes();
    for (const std::string& cliente : clientes) {
        std::vector<std::string> datosCliente = split(cliente, ';');
        if (datosCliente.size() >= 2 && datosCliente[1] == cedula) {
            return true;
        }
    }
    return false;
}

bool Logic_Cliente::registrarCliente(const Cliente& cliente) {
    std::vector<std::string> clientes = cdao.loadClientes();
    for (const std::string& clienteStr : clientes) {
        std::vector<std::string> datosCliente = split(clienteStr, ';');
        if (datosCliente.size() >= 2 && datosCliente[1] == cliente.getCedula()) {
            return false; // Cliente ya existe
        }
    }
    cdao.writeCliente(cliente);
    return true;
}
