#include"Headers/empleado.h"
employee::employee() {
    this->nombres = "";
    this->cedula = 0;
    this->edad = 0;
    this->genero = "";
    this->cargo = "";
}

employee::~employee() {}

employee::employee(string n, long ce, int e, string g, string ca)
    : nombres(n), cedula(ce), edad(e), genero(g), cargo(ca) {}

string employee::getNombres() {
    return nombres;
}

long employee::getCedula() {
    return cedula;
}

int employee::getEdad() {
    return edad;
}

string employee::getGenero() {
    return genero;
}

string employee::getCargo() {
    return cargo;
}

void employee::setNombre(string n) {
    this->nombres = n;
}

void employee::setCedula(long ce) {
    this->cedula = ce;
}

void employee::setEdad(int e) {
    this->edad = e;
}

void employee::setGenero(string g) {
    this->genero = g;
}

void employee::setCargo(string ca) {
    this->cargo = ca;
}
string employee::information() const {
    return nombres + ";" + to_string(cedula) + ";" + to_string(edad) + ";" + genero + ";" + cargo;
}
