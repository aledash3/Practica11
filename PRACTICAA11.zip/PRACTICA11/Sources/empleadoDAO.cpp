#include"Headers/empleadoDAO.h"
#include"Headers/empleado.h"
#include <iostream>
#include <sstream>

using namespace std;

empleadoDAO::empleadoDAO() {}

empleadoDAO::empleadoDAO(const employee& e) {
    this->empleado = e;
}

vector<string> empleadoDAO::loadEmployees() {
    vector<string> empleados;
    archivo.open(path, ios::in);
    if (archivo.is_open()) {
        string linea = "";
        while (getline(archivo, linea)) {
            empleados.push_back(linea);
        }
        archivo.close();
    }
    return empleados;
}

void empleadoDAO::writeEmployees() {
    archivo.open(path, ios::app);
    if (archivo.is_open()) {
        archivo << empleado.information() << std::endl;
        archivo.close();
    }
}
