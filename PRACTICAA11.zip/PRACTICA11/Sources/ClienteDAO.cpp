#include"Headers/ClienteDAO.h"
#include <iostream>

ClienteDAO::ClienteDAO() {}

ClienteDAO::ClienteDAO(const Cliente& c) : cliente(c) {}

vector<string> ClienteDAO::loadClientes() {
    vector<string> clientes;
    archivo.open("C:/Users/David Cruz/Desktop/PRACTIK 11/clientes.txt", ios::in);
    if (archivo.is_open()) {
        string linea = "";
        while (getline(archivo, linea)) {
            clientes.push_back(linea);
        }
        archivo.close();
    }
    return clientes;
}

void ClienteDAO::writeCliente(const Cliente& c) {
    archivo.open("C:/Users/David Cruz/Desktop/PRACTIK 11/clientes.txt", ios::app);
    if (archivo.is_open()) {
        archivo << c.getNombres() << ";" << c.getCedula() << ";" << c.getCorreo() << ";" << c.getTelefono() << ";" << c.getDireccion() << endl;
        archivo.close();
    }
}
