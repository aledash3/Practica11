#include"Headers/logic_employee.h"
#include <string>

using namespace std;

bool logic_employee::registrarEmpleado(string &nombres, long &cedula, int &edad, string &genero, string &cargo) {
    employee empleado(nombres, cedula, edad, genero, cargo);
    empleadoDAO edao(empleado);
    edao.writeEmployees();
    return true;
}
