#include"Headers/proveedoresDAO.h"
#include<iostream>
proveedoresDAO::proveedoresDAO(){

}
proveedoresDAO::proveedoresDAO(const proveedores& p){
    this->pro=p;
}
vector<string> proveedoresDAO::loadProveedores(){
    vector<string> proveedores;
    archivo.open("C:/Users/David Cruz/Desktop/PRACTIK 11/proveedores.txt",ios::in);
    if(archivo.is_open()){
        string linea="";
        while(getline(archivo,linea)){
            cout<<linea<<endl;
            proveedores.push_back(linea);
        }
        archivo.close();
    }
    return proveedores;
}
