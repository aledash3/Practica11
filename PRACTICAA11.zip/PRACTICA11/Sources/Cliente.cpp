#include "Headers/Cliente.h"
Cliente::Cliente() {
    this->nombres = "";
    this->cedula = "";
    this->correo = "";
    this->telefono = "";
    this->direccion = "";
}

Cliente::Cliente(string nombres, string cedula, string correo, string telefono, string direccion)
    : nombres(nombres), cedula(cedula), correo(correo), telefono(telefono), direccion(direccion) {}

Cliente::~Cliente() {}

string Cliente::getNombres() const {
    return nombres;
}

string Cliente::getCedula() const {
    return cedula;
}

string Cliente::getCorreo() const {
    return correo;
}

string Cliente::getTelefono() const {
    return telefono;
}

string Cliente::getDireccion() const {
    return direccion;
}

void Cliente::setNombres(string nombres) {
    this->nombres = nombres;
}

void Cliente::setCedula(string cedula) {
    this->cedula = cedula;
}

void Cliente::setCorreo(string correo) {
    this->correo = correo;
}

void Cliente::setTelefono(string telefono) {
    this->telefono = telefono;
}

void Cliente::setDireccion(string direccion) {
    this->direccion = direccion;
}
