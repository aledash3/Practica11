#include "Headers/proveedores.h"
proveedores::proveedores(){
    this->razonSocial="";
    this->telefono="";
    this->nombres="";
    this->email="";
}
proveedores::~proveedores(){

}
proveedores::proveedores(string r,string t,string n ,string e):razonSocial(r),nombres(n),telefono(t),email(e){

}
string proveedores::getRazonSocial()const{
    return razonSocial;
}
string proveedores::getNombres()const{
    return nombres;
}
string proveedores::getTelefono()const{
    return telefono;
}
string proveedores::getEmail()const{
    return email;
}
void proveedores::setRazonSocial(string r){
    razonSocial=r;
}
void proveedores::setNombres(string n){
    nombres=n;
}
void proveedores::setTelefono(string t){
    telefono=t;
}
void proveedores::setEmail(string e){
    email=e;
}
