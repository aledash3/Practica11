#ifndef CLIENTE_H
#define CLIENTE_H
#include <string>
using namespace std;

class Cliente {
private:
    string nombres;
    string cedula;
    string correo;
    string telefono;
    string direccion;

public:
    Cliente();
    Cliente(string nombres, string cedula, string correo, string telefono, string direccion);
    ~Cliente();

    string getNombres() const;
    string getCedula() const;
    string getCorreo() const;
    string getTelefono() const;
    string getDireccion() const;

    void setNombres(string nombres);
    void setCedula(string cedula);
    void setCorreo(string correo);
    void setTelefono(string telefono);
    void setDireccion(string direccion);
};
#endif // CLIENTE_H
