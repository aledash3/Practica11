#ifndef EMPLEADO_H
#define EMPLEADO_H
#include <string>

using namespace std;

class employee {
private:
    string nombres;
    long cedula;
    int edad;
    string genero;
    string cargo;
public:
    employee();
    ~employee();
    employee(string, long, int, string, string);

    string getNombres();
    long getCedula();
    int getEdad();
    string getGenero();
    string getCargo();

    void setNombre(string);
    void setCedula(long);
    void setEdad(int);
    void setGenero(string);
    void setCargo(string);

    string information() const;
};
#endif // EMPLEADO_H
