#ifndef VENTASDAO_H
#define VENTASDAO_H

#endif // VENTASDAO_H
