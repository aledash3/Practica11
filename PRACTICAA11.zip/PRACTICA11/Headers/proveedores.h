#ifndef PROVEEDORES_H
#define PROVEEDORES_H
#include<string>
using namespace std;
class proveedores{
private:
    string razonSocial;
    string nombres;
    string telefono;
    string email;
public:
    proveedores();
    ~proveedores();
    proveedores(string,string,string,string);
    string getRazonSocial()const;
    string getNombres()const;
    string getTelefono()const;
    string getEmail()const;
    void setRazonSocial(string);
    void setNombres(string);
    void setTelefono(string);
    void setEmail(string);
};

#endif // PROVEEDORES_H
