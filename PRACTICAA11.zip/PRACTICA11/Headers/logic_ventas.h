#ifndef LOGIC_VENTAS_H
#define LOGIC_VENTAS_H

#endif // LOGIC_VENTAS_H
