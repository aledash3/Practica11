#ifndef PROVEEDORESDAO_H
#define PROVEEDORESDAO_H
#include"Headers/proveedores.h"
#include <vector>
#include<fstream>
class proveedoresDAO{
private:
    proveedores pro;
    fstream archivo;
private:
    proveedoresDAO();
    proveedoresDAO(const proveedores& p);
    vector<string> loadProveedores();
};

#endif // PROVEEDORESDAO_H
