#ifndef LOGIC_CLIENTE_H
#define LOGIC_CLIENTE_H

#include "Headers/ClienteDAO.h"


class Logic_Cliente {
private:
    ClienteDAO cdao;

public:
    bool validarCliente(string cedula);
    bool registrarCliente(const Cliente& cliente);
};

#endif // LOGIC_CLIENTE_H
