#ifndef EMPLEADODAO_H
#define EMPLEADODAO_H
#include"Headers/empleado.h"
#include <vector>
#include <fstream>
#include <QString>

class empleadoDAO {
private:
    employee empleado;
    fstream archivo;
    string path = "C:/Users/David Cruz/Desktop/PRACTIK 11/empleados.txt";

public:
    empleadoDAO();
    empleadoDAO(const employee&);
    void writeEmployees();
    vector<string> loadEmployees(); // Leer todos los registros del archivo y almacenarlos en el vector
};

#endif // EMPLEADODAO_H
