#ifndef LOGIC_EMPLOYEE_H
#define LOGIC_EMPLOYEE_H
#include"Headers/empleado.h"
#include"Headers/empleadoDAO.h"
class logic_employee {
private:
    empleadoDAO edao;
    employee e;
public:
    bool registrarEmpleado(string &nombres, long &cedula, int &edad, string &genero, string &cargo);
};

#endif // LOGIC_EMPLOYEE_H
