#ifndef CLIENTEDAO_H
#define CLIENTEDAO_H
#include "Headers/Cliente.h"
#include <vector>
#include <fstream>

class ClienteDAO {
private:
    Cliente cliente;
    fstream archivo;

public:
    ClienteDAO();
    ClienteDAO(const Cliente&);
    vector<string> loadClientes();
    void writeCliente(const Cliente&);
};
#endif // CLIENTEDAO_H
