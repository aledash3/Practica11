#include "registerproveedores.h"
#include "ui_registerproveedores.h"
#include<QMessageBox>
#include<QFile>
registerproveedores::registerproveedores(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::registerproveedores)
{
    ui->setupUi(this);
    connect(ui->btn_add2, &QPushButton::clicked, this, &registerproveedores::addPorveedores);
}

registerproveedores::~registerproveedores()
{
    delete ui;
}
void registerproveedores::addPorveedores(){
    QString razonSocial = ui->txt_RazonSocial->text();
    QString nombres = ui->txt_nombres->text();
    QString telefono = ui->txt_telefono->text();
    QString email = ui->txt_email->text();

    if (razonSocial.isEmpty() || nombres.isEmpty() || telefono.isEmpty() || email.isEmpty()) {
        QMessageBox::warning(this, "Registro de Proveedor", "Todos los campos son obligatorios.");
        return;
    }
    saveUserToFile(razonSocial,nombres,telefono,email);
}
void registerproveedores::saveUserToFile(const QString &razonSocial, const QString &nombres, const QString &telefono,const QString &email){
    QFile file("C://ejerciciosFS//ejercicio1//proveedores.txt");
    if (!file.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::critical(this, "Registro de Proveedor", "No se pudo abrir el archivo para escribir.");
        return;
    }

    QTextStream out(&file);
    out << razonSocial << ";" << nombres <<";"<<telefono<<";"<<email<< "\n";
    file.close();

    QMessageBox::information(this, "Registro de Proveedor", "Proveedor registrado exitosamente.");
    ui->txt_RazonSocial->clear();
    ui->txt_nombres->clear();
    ui->txt_telefono->clear();
    ui->txt_email->clear();
}
