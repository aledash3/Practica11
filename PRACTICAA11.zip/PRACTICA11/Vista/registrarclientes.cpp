#include "registrarclientes.h"
#include "ui_registrarclientes.h"
#include <QMessageBox>

RegistrarClientes::RegistrarClientes(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::RegistrarClientes)
{
    ui->setupUi(this);
    connect(ui->btn_addCliente,SIGNAL(clicked()),this,SLOT(on_addButton_clicked()));
}

RegistrarClientes::~RegistrarClientes()
{
    delete ui;
}

void RegistrarClientes::on_addButton_clicked() {
    QString nombres = ui->nombresLineEdit->text();
    QString cedula = ui->cedulaLineEdit->text();
    QString correo = ui->correoLineEdit->text();
    QString telefono = ui->telefonoLineEdit->text();
    QString direccion = ui->direccionLineEdit->text();

    Cliente nuevoCliente(nombres.toStdString(), cedula.toStdString(), correo.toStdString(), telefono.toStdString(), direccion.toStdString());

    Logic_Cliente logicCliente;
    if (logicCliente.registrarCliente(nuevoCliente)) {
        QMessageBox::information(this, "Éxito", "Cliente registrado correctamente");
    } else {
        QMessageBox::warning(this, "Error", "El cliente ya existe");
    }
}
