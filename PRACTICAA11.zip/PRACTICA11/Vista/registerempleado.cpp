#include "registerempleado.h"
#include "ui_registerempleado.h"
#include<QMessageBox>
registerEmpleado::registerEmpleado(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::registerEmpleado)
{
    ui->setupUi(this);
    ptrLe=&le;

    connect(ui->btn_addEmployee,SIGNAL(clicked()),this,SLOT(registrar()));

    ui->comboBox->addItem("Hombre");
    ui->comboBox->addItem("Mujer");

}

registerEmpleado::~registerEmpleado()
{
    delete ui;
}



void registerEmpleado::registrar(){
    string nombres = ui->txt_nombres->text().toStdString();
    long cedula = ui->txt_cedula->text().toLong();
    int edad = ui->spinBox->value();
    string genero = ui->comboBox->currentText().toStdString();
    string cargo = ui->txt_cargo->text().toStdString();

    logic_employee le;
    if (ptrLe->registrarEmpleado(nombres, cedula, edad, genero, cargo)){
        QMessageBox::information(this, "Registro de Empleado", "Empleado registrado con éxito.");
    } else {
        QMessageBox::warning(this, "Registro de Empleado", "Error al registrar el empleado.");
    }
}

