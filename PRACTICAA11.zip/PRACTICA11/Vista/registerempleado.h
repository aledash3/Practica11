#ifndef REGISTEREMPLEADO_H
#define REGISTEREMPLEADO_H

#include <QWidget>
#include"Headers/logic_employee.h"
namespace Ui {
class registerEmpleado;
}

class registerEmpleado : public QWidget
{
    Q_OBJECT

public:
    explicit registerEmpleado(QWidget *parent = nullptr);
    ~registerEmpleado();

private:
    Ui::registerEmpleado *ui;
    logic_employee le,
        *ptrLe=nullptr;
private slots:
    void registrar();
};

#endif // REGISTEREMPLEADO_H
