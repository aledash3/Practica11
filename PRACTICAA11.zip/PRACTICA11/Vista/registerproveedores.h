#ifndef REGISTERPROVEEDORES_H
#define REGISTERPROVEEDORES_H

#include <QWidget>

namespace Ui {
class registerproveedores;
}

class registerproveedores : public QWidget
{
    Q_OBJECT

public:
    explicit registerproveedores(QWidget *parent = nullptr);
    ~registerproveedores();
private slots:
    void addPorveedores();
private:
    Ui::registerproveedores *ui;
    void saveUserToFile(const QString &razonSocial, const QString &nombres, const QString &telefono,const QString &email);
};

#endif // REGISTERPROVEEDORES_H
