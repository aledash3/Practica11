#ifndef REGISTRARCLIENTES_H
#define REGISTRARCLIENTES_H

#include <QWidget>
#include"Headers/Cliente.h"
#include "Headers/Logic_Cliente.h"
namespace Ui {
class RegistrarClientes;
}

class RegistrarClientes : public QWidget
{
    Q_OBJECT

public:
    explicit RegistrarClientes(QWidget *parent = nullptr);
    ~RegistrarClientes();
private slots:
    void on_addButton_clicked();
private:
    Ui::RegistrarClientes *ui;
};

#endif // REGISTRARCLIENTES_H
