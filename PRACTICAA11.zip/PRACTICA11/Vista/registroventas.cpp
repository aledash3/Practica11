#include "registroventas.h"
#include "ui_registroventas.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>

registroVentas::registroVentas(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::registroVentas)
{
    ui->setupUi(this);

    cargarDatosClientes();
    cargarDatosEmpleados();
    cargarDatosProductos();

    connect(ui->btn_loadCliente, &QPushButton::clicked, this, &registroVentas::on_lineEdit_CedulaCliente_editingFinished);
    connect(ui->btn_addProducto, &QPushButton::clicked, this, &registroVentas::aniadirproducto);
    connect(ui->btn_Pagar, &QPushButton::clicked, this, &registroVentas::pagar);
}

registroVentas::~registroVentas()
{
    delete ui;
}

void registroVentas::cargarDatosClientes()
{
    QFile file(dataDirectory + "clientes.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir el archivo de clientes.");
        return;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(';');  // Cambiar la separación a punto y coma
        if (fields.size() >= 5) {
            clientes[fields[1]] = fields;
        }
    }
    file.close();
}

void registroVentas::cargarDatosEmpleados()
{
    QFile file(dataDirectory + "empleados.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir el archivo de empleados.");
        return;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(';'); // Dividir la línea por punto y coma
        if (!fields.isEmpty()) {
            QString nombreEmpleado = fields[0]; // Usar solo el primer índice
            empleados.append(nombreEmpleado);
            ui->comboBox_Empleados->addItem(nombreEmpleado);
        }
    }
    file.close();
}


void registroVentas::cargarDatosProductos()
{
    QFile file(dataDirectory + "productos.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir el archivo de productos.");
        return;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(';');  // Asegúrate de usar punto y coma (;) como separador
        if (fields.size() >= 3) {
            QString nombreProducto = fields[0];
            int stock = fields[1].toInt();
            double precio = fields[2].toDouble();
            productos[nombreProducto] = precio;
            stockProductos[nombreProducto] = stock; // Guardamos el stock del producto en stockProductos
            ui->comboBox_Productos->addItem(nombreProducto);  // Añadir el nombre del producto al ComboBox
        }
    }
    file.close();
}

void registroVentas::on_lineEdit_CedulaCliente_editingFinished()
{
    QString cedula = ui->lineEdit_CedulaCliente->text();
    if (clientes.contains(cedula)) {
        QStringList datos = clientes[cedula];
        ui->txt_NombreCliente->setText(datos[0]);      // Nombre del cliente
        ui->txt_DireccionCliente->setText(datos[4]);   // Dirección del cliente
        ui->txt_TelfCliente->setText(datos[3]);        // Teléfono del cliente
        ui->txt_CorreoCliente->setText(datos[2]);      // Correo del cliente
    } else {
        QMessageBox::warning(this, "Advertencia", "Cliente no encontrado.");
        ui->txt_NombreCliente->clear();      // Limpiar campos si el cliente no se encuentra
        ui->txt_DireccionCliente->clear();
        ui->txt_TelfCliente->clear();
        ui->txt_CorreoCliente->clear();
    }
}

void registroVentas::aniadirproducto()
{
    QString producto = ui->comboBox_Productos->currentText();
    int cantidad = ui->lineEdit_Cantidad->text().toInt();

    if (cantidad <= 0) {
        QMessageBox::warning(this, "Advertencia", "La cantidad debe ser mayor que cero.");
        return;
    }

    // Verificar si hay suficiente stock
    if (stockProductos.contains(producto) && stockProductos[producto] >= cantidad) {
        double precio = productos[producto];
        double total = cantidad * precio;

        int row = ui->tableWidget_Compras->rowCount();
        ui->tableWidget_Compras->insertRow(row);
        ui->tableWidget_Compras->setItem(row, 0, new QTableWidgetItem(producto));
        ui->tableWidget_Compras->setItem(row, 1, new QTableWidgetItem(QString::number(cantidad)));
        ui->tableWidget_Compras->setItem(row, 2, new QTableWidgetItem(QString::number(precio)));
        ui->tableWidget_Compras->setItem(row, 3, new QTableWidgetItem(QString::number(total)));

        actualizarTotal();
        actualizarStock(producto, cantidad); // Actualizar el stock del producto
    } else {
        QMessageBox::warning(this, "Advertencia", "Stock insuficiente para este producto.");
    }
}

void registroVentas::actualizarTotal()
{
    double subtotal = 0;
    for (int i = 0; i < ui->tableWidget_Compras->rowCount(); ++i) {
        subtotal += ui->tableWidget_Compras->item(i, 3)->text().toDouble();
    }

    double iva = subtotal * 0.15;
    double total = subtotal + iva;

    ui->txt_Subtotal->setText(QString::number(subtotal));
    ui->txt_Iva->setText(QString::number(iva));
    ui->txt_Total->setText(QString::number(total));
}

void registroVentas::pagar()
{
    QString cedula = ui->lineEdit_CedulaCliente->text();
    QString nombreCliente = ui->txt_NombreCliente->text();
    QString direccionCliente = ui->txt_DireccionCliente->text();
    QString telfCliente = ui->txt_TelfCliente->text();
    QString correoCliente = ui->txt_CorreoCliente->text();
    QString empleado = ui->comboBox_Empleados->currentText();

    QFile file(dataDirectory + "ventas.txt");
    if (!file.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir el archivo de ventas.");
        return;
    }

    QTextStream out(&file);
    out << cedula << "," << nombreCliente << "," << direccionCliente << "," << telfCliente << "," << correoCliente << "," << empleado << "\n";

    for (int i = 0; i < ui->tableWidget_Compras->rowCount(); ++i) {
        QString producto = ui->tableWidget_Compras->item(i, 0)->text();
        QString cantidad = ui->tableWidget_Compras->item(i, 1)->text();
        QString precio = ui->tableWidget_Compras->item(i, 2)->text();
        QString total = ui->tableWidget_Compras->item(i, 3)->text();

        out << producto << "," << cantidad << "," << precio << "," << total << "\n";
    }

    file.close();
    QMessageBox::information(this, "Éxito", "Venta registrada exitosamente.");
}

void registroVentas::actualizarStock(const QString &producto, int cantidad)
{
    if (stockProductos.contains(producto)) {
        stockProductos[producto] -= cantidad; // Actualizar el stock del producto
    }
}

void registroVentas::recargarDatos()
{
    // Limpiar datos existentes
    clientes.clear();
    productos.clear();
    stockProductos.clear();
    empleados.clear();
    ui->comboBox_Productos->clear();
    ui->comboBox_Empleados->clear();

    // Recargar datos de clientes
    QFile fileClientes(dataDirectory + "clientes.txt");
    if (!fileClientes.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir el archivo de clientes.");
        return;
    }

    QTextStream inClientes(&fileClientes);
    while (!inClientes.atEnd()) {
        QString line = inClientes.readLine();
        QStringList fields = line.split(';');  // Cambiar la separación a punto y coma
        if (fields.size() >= 5) {
            clientes[fields[1]] = fields;
        }
    }
    fileClientes.close();

    // Recargar datos de productos
    QFile fileProductos(dataDirectory + "productos.txt");
    if (!fileProductos.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir el archivo de productos.");
        return;
    }

    QTextStream inProductos(&fileProductos);
    while (!inProductos.atEnd()) {
        QString line = inProductos.readLine();
        QStringList fields = line.split(';');  // Asegúrate de usar punto y coma (;) como separador
        if (fields.size() >= 3) {
            QString nombreProducto = fields[0];
            int stock = fields[1].toInt();
            double precio = fields[2].toDouble();
            productos[nombreProducto] = precio;
            stockProductos[nombreProducto] = stock; // Guardamos el stock del producto en stockProductos
            ui->comboBox_Productos->addItem(nombreProducto);  // Añadir el nombre del producto al ComboBox
        }
    }
    fileProductos.close();

    // Recargar datos de empleados
    QFile fileEmpleados(dataDirectory + "empleados.txt");
    if (!fileEmpleados.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "No se pudo abrir el archivo de empleados.");
        return;
    }

    QTextStream inEmpleados(&fileEmpleados);
    while (!inEmpleados.atEnd()) {
        QString line = inEmpleados.readLine();
        QStringList fields = line.split(';'); // Dividir la línea por punto y coma
        if (!fields.isEmpty()) {
            QString nombreEmpleado = fields[0]; // Usar solo el primer índice
            empleados.append(nombreEmpleado);
            ui->comboBox_Empleados->addItem(nombreEmpleado);
        }
    }
    fileEmpleados.close();
}
