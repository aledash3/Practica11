#ifndef REGISTROVENTAS_H
#define REGISTROVENTAS_H

#include <QWidget>
#include <QString>
#include <QVector>
#include <QMap>

namespace Ui {
class registroVentas;
}

class registroVentas : public QWidget
{
    Q_OBJECT

public:
    explicit registroVentas(QWidget *parent = nullptr);
    ~registroVentas();
    void recargarDatos(); // Función para recargar datos

private slots:
    void aniadirproducto();
    void pagar();
    void on_lineEdit_CedulaCliente_editingFinished();

private:
    Ui::registroVentas *ui;
    QMap<QString, QStringList> clientes;
    QVector<QString> empleados;
    QMap<QString, double> productos;
    QMap<QString, int> stockProductos; // Mapa para almacenar el stock de productos

    const QString dataDirectory = "C:/Users/David Cruz/Desktop/PRACTIK 11/";

    void cargarDatosClientes();
    void cargarDatosEmpleados();
    void cargarDatosProductos();
    void actualizarTotal();
    void actualizarStock(const QString &producto, int cantidad);
};

#endif // REGISTROVENTAS_H



