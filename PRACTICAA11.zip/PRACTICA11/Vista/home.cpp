#include "home.h"
#include "ui_home.h"

Home::Home(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Home)
    , uiRp(new registerProduct)
    , uiRu(new registeruser)
    , uiVp(new viewproducts)
    , uiRv(new registerproveedores)
    , uiRe(new registerEmpleado)
    , uiRc (new RegistrarClientes)
    , uiRegistroVentas(new registroVentas)

{
    ui->setupUi(this);
    connect(ui->btn_registrar, SIGNAL(clicked()),this,SLOT(callRegisterProduct()));
    connect(ui->btn_usuarios,SIGNAL(clicked()),this,SLOT(callRegisterUser()));
    connect(ui->btn_consultar,SIGNAL(clicked()),this,SLOT(viewProducts()));
    connect(ui->btn_proveedores,SIGNAL(clicked()),this,SLOT(callRegisterProveedores()));
    connect(ui->btn_empleados,SIGNAL(clicked()),this,SLOT(callRegisterEmpleados()));
    connect(ui->btn_clientes,SIGNAL(clicked()),this,SLOT(callRegisterCLientes()));
    connect(ui->btn_ventas, SIGNAL(clicked()), this, SLOT(callRegistroVentas()));

}

Home::~Home()
{
    delete ui;
}
void Home::callRegisterProduct(){
    uiRp->show();
}
void Home::callRegisterUser(){
    uiRu->show();
}
void Home::viewProducts(){
    uiVp->show();
}
void Home::callRegisterProveedores(){
    uiRv->show();
}
void Home::callRegisterEmpleados(){
    uiRe->show();
}
void Home::callRegisterCLientes(){
    uiRc->show();
}
void Home::callRegistroVentas()
{
    uiRegistroVentas->show();
    uiRegistroVentas->recargarDatos();
}
