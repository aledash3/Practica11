#ifndef HOME_H
#define HOME_H
#include"Vista/registerempleado.h"
#include"Vista/registeruser.h"
#include "Vista/registerproduct.h"
#include "Vista/viewproducts.h"
#include"Vista/registerproveedores.h"
#include "Vista/registrarclientes.h"
#include "Vista/registroventas.h"
#include <QWidget>

namespace Ui {
class Home;
}

class Home : public QWidget
{
    Q_OBJECT

public:
    explicit Home(QWidget *parent = nullptr);
    ~Home();

private:
    Ui::Home *ui;
    registerProduct *uiRp;
    registeruser *uiRu;
    viewproducts *uiVp;
    registerproveedores *uiRv;
    registerEmpleado *uiRe;
    RegistrarClientes *uiRc;
    registroVentas *uiRegistroVentas;
private slots:
    void callRegisterProduct();
    void callRegisterUser();
    void viewProducts();
    void callRegisterProveedores();
    void callRegisterEmpleados();
    void callRegisterCLientes();
    void callRegistroVentas();
};

#endif // HOME_H
